---
title: Cómo borrar conjuntos de datos
image: 
date: 2021-07-27
category: Tutorial gestores
youtube_url: https://www.youtube.com/watch?v=rI0Lh9tLBzA&list=PL_K5dhbfg0DowESVMxKa2jpzcBsuqB-0h&index=10&ab_channel=Datasketch
---



