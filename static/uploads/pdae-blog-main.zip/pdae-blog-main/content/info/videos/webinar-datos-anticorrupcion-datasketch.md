---
title: "Sesión de capacitación: Datos para la lucha anti-corrupción"
image: 
date: 2021-07-27
category: Webinar
youtube_url: https://www.youtube.com/watch?v=bpHO0--iHv8&ab_channel=Datasketch
---





