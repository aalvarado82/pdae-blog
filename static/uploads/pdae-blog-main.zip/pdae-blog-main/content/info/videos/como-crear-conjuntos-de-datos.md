---
title: Cómo crear conjuntos de datos
image: 
date: 2021-07-27
category: Tutorial gestores
youtube_url: https://www.youtube.com/watch?v=dO4Itu4cwvM&list=PL_K5dhbfg0DowESVMxKa2jpzcBsuqB-0h&index=9&ab_channel=Datasketch
---



