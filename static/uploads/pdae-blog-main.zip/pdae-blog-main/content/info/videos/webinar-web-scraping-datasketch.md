---
title: "Sesión de capacitación: Web scraping"
image: 
date: 2021-07-27
category: Webinar
youtube_url: https://www.youtube.com/watch?v=Unvzpombk7M&ab_channel=Datasketch
---

En este webinar de [datasketch](http://datasketch.co) se discuten conceptos sobre el uso de tecnologías de estructuración de datos a partir de información de páginas web. Se exploran diferentes herramientas para extraer datos de páginas web e incluso otras para estructurar datos a partir de información en archivos PDF. 

