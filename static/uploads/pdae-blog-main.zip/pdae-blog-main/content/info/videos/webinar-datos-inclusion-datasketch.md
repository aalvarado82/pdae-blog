---
title: "Sesión de capacitación: Inclusión y diversidad - datos para el bien común"
image: 
date: 2021-07-27
category: Webinar
youtube_url: https://www.youtube.com/watch?v=4HPS0A7lf64&ab_channel=Datasketch
---

En este webinar de [datasketch](http://datasketch.co) se discuten conceptos sobre el uso de datos para la inclusión. Se abordan riesgos y oportunidades al momento de utilizar información de manera responsable para involucrar a comunidades vulnerables desde la planeación de captura de información, hasta cómo las comunicamos. 

