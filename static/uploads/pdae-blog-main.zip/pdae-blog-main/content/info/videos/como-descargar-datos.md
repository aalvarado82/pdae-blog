---
title: Cómo descargar datos
image: 
date: 2021-07-27
category: Tutorial usuarios
youtube_url: https://www.youtube.com/watch?v=zqQnD0nSU_I&list=PL_K5dhbfg0DowESVMxKa2jpzcBsuqB-0h&index=1&ab_channel=Datasketch
---



