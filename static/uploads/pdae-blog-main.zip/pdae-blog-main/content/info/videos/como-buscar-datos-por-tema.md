---
title: Cómo buscar un conjunto de datos por tema
image: 
date: 2021-07-27
category: Tutorial usuarios
youtube_url: https://www.youtube.com/watch?v=CuOY5T7-wDo&list=PL_K5dhbfg0DowESVMxKa2jpzcBsuqB-0h&index=2&ab_channel=Datasketch
---



