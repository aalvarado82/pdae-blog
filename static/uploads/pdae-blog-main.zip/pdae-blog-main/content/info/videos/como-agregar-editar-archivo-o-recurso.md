---
title: Cómo agregar y editar un archivo o recurso
image: 
date: 2021-07-27
category: Tutorial gestores
youtube_url: https://www.youtube.com/watch?v=aIBPeGoTn_E&list=PL_K5dhbfg0DowESVMxKa2jpzcBsuqB-0h&index=8&ab_channel=Datasketch
---



