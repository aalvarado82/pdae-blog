---
title: "3. ¿Por qué las entidades de gobierno publican datos abiertos?"
date: 2021-07-21T14:26:03-05:00
draft: false
standalone: true
---

Gracias a la publicación de datos abiertos, el gobierno puede transparentar su gestión e involucrar a la sociedad para que realice el seguimiento de sus acciones. Además, impulsa la generación de emprendimientos, propuestas y soluciones basadas en el análisis de datos abiertos.
