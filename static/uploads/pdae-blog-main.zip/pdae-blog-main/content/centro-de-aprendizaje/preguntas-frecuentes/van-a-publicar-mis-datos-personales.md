---
title: "4. ¿Van a publicar mis datos personales?"
date: 2021-07-21T14:24:31-05:00
draft: false
standalone: true
---

Las entidades gubernamentales generan y custodian una gran cantidad de datos. En cumplimiento de la ley, las instituciones tienen especial cuidado para proteger los datos personales cuando se trata de publicar datos abiertos.

Adicionalmente, la Política y la Guía de Datos Abiertos establecen lineamientos a las entidades del Ejecutivo para que los datos a publicar cumplan con las normas de protección de datos personales.
