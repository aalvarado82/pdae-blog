---
title: "2. ¿Para qué sirven los datos abiertos?"
date: 2021-07-21T14:27:05-05:00
draft: false
standalone: true
---

Su uso facilita la investigación, permite realizar análisis y aporta a que las decisiones del gobierno sean más eficaces y cercanas a la realidad. Los datos abiertos tienen las características técnicas que permiten su procesamiento en computadoras.
