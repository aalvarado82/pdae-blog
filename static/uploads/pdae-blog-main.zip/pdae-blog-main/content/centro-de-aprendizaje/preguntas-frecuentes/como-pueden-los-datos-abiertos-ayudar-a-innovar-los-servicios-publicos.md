---
title: "7. ¿Como pueden los datos abiertos ayudar a innovar los servicios publicos?"
date: 2021-07-21T14:19:11-05:00
draft: false
standalone: true
---

A través de la publicación de datos abiertos -y en línea con el enfoque de Gobierno Abierto- se promueve la participación ciudadana y la innovación; así, los ciudadanos pueden llegar a ser actores fundamentales en la validación de la información y generar ideas, proyectos, investigaciones o emprendimientos enfocados al mejoramiento de los servicios públicos, a nivel nacional. Asimismo, la participación ciudadana en el uso y validación de datos abiertos exige a las organizaciones a mejorar la publicación de sus datos, lo cual podría influir en el mejoramiento, optimización e, inclusive, automatización de procesos que garanticen la veracidad de la data.