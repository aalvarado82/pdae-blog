---
title: "6. ¿Por qué es importante liberar datos?"
date: 2021-07-21T14:20:55-05:00
draft: false
standalone: true
---

La publicación de datos abiertos responde a los principios de transparencia, participación ciudadana y generación de valor, a través de la innovación. A la par, responde a un derecho de la ciudadanía de conocer las acciones que el Gobierno central realiza.
