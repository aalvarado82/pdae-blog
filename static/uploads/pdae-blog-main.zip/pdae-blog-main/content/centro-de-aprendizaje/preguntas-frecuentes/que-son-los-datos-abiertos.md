---
title: "1. ¿Qué son los datos abiertos?"
date: 2021-07-21T14:28:00-05:00
draft: false
standalone: true
---

Son datos digitales puestos a disposición de usuarios como la ciudadanía, el sector privado, instituciones públicas o academia, que reúnen las características necesarias (técnicas y jurídicas) para su acceso y uso sin restricciones.
