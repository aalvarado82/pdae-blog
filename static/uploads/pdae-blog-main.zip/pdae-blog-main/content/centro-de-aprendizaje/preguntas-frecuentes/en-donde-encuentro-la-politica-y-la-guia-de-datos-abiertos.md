---
title: "5. ¿En dónde encuentro la Política y la Guía de Datos Abiertos?"
date: 2021-07-21T14:23:22-05:00
draft: false
standalone: true
---

La Política de Datos Abiertos está disponible en el siguiente enlace: [Descargar Política de Datos Abiertos](https://bit.ly/PoliticaDatosAbiertosEC).

La Guía de Datos Abiertos está disponible en el siguiente enlace: [Descargar Guía de Datos Abiertos](https://bit.ly/3wD7RqG).
