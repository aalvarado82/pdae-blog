---
title: "Guía de Datos Abiertos"
date: 2021-07-21T14:06:36-05:00
draft: false
description: Esta guía tiene por objetivo proporcionar criterios técnicos y metodológicos para planificar, abrir, publicar y promover la utilización de los datos abiertos gubernamentales.
---

Esta guía tiene por objetivo proporcionar criterios técnicos y metodológicos para planificar, abrir, publicar y promover la utilización de los datos abiertos gubernamentales.

**Enlace:** [http://bit.ly/GuiaDatosAbiertosEc](http://bit.ly/GuiaDatosAbiertosEc)

