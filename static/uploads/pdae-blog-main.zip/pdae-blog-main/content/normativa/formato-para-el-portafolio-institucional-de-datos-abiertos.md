---
title: "Formato para el Portafolio Institucional De Datos Abiertos"
date: 2021-07-21T14:12:11-05:00
draft: false
description: Es una matriz para ingresar el conjunto de datos abiertos priorizados.
---

Es una matriz para ingresar el conjunto de datos abiertos priorizados.

**Enlace:** [http://bit.ly/PortafolioDA](http://bit.ly/PortafolioDA)

