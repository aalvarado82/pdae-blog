---
title: "Manual para la construcción del Portafolio Institucional De Datos Abiertos"
date: 2021-07-21T14:10:14-05:00
draft: false
description: Su objetivo es facilitar la construcción del Portafolio Institucional de Datos Abiertos, mediante el uso de una herramienta que permita la evaluación de criterios para priorizar e incluir los conjuntos de datos abiertos con mayor potencial.
---

Su objetivo es facilitar la construcción del Portafolio Institucional de Datos Abiertos, mediante el uso de una herramienta que permita la evaluación de criterios para priorizar e incluir los conjuntos de datos abiertos con mayor potencial.

**Enlace:** [http://bit.ly/ConstruccionPortafolioDA](http://bit.ly/ConstruccionPortafolioDA)

