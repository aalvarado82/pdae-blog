---
title: "Política de Datos Abiertos"
date: 2021-07-21T14:01:05-05:00
draft: false
description: Tiene como objetivo implementar los datos abiertos en la Función Ejecutiva para fortalecer la participación ciudadana, la transparencia gubernamental, mejorar la eficiencia en la gestión pública, promover la investigación, el emprendimiento y la innovación en la sociedad.
---

Tiene como objetivo implementar los datos abiertos en la Función Ejecutiva para fortalecer la participación ciudadana, la transparencia gubernamental, mejorar la eficiencia en la gestión pública, promover la investigación, el emprendimiento y la innovación en la sociedad.

**Enlace:** [https://bit.ly/PoliticaDatosAbiertosEC](https://bit.ly/PoliticaDatosAbiertosEC)

